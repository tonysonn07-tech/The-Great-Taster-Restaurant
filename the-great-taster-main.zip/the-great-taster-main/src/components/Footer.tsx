import { MapPin, Phone, Clock, Instagram } from "lucide-react";

const Footer = () => (
  <footer className="py-16 bg-card border-t border-border">
    <div className="container mx-auto px-6">
      <div className="grid md:grid-cols-3 gap-12 mb-12">
        <div>
          <h3 className="font-display text-2xl font-bold text-gold-gradient mb-4">Great Taster</h3>
          <p className="font-body text-sm text-foreground/50 leading-relaxed">
            Cuisine pan-africaine d'exception dans un cadre prestigieux. Une célébration des saveurs de l'Afrique de l'Ouest.
          </p>
        </div>

        <div className="space-y-4">
          <h4 className="font-display text-lg font-semibold text-foreground mb-4">Contact</h4>
          <div className="flex items-center gap-3 text-foreground/50">
            <MapPin size={16} className="text-primary flex-shrink-0" />
            <span className="font-body text-sm">12 Rue de la Gastronomie, 75008 Paris</span>
          </div>
          <div className="flex items-center gap-3 text-foreground/50">
            <Phone size={16} className="text-primary flex-shrink-0" />
            <span className="font-body text-sm">+33 1 42 00 00 00</span>
          </div>
          <div className="flex items-center gap-3 text-foreground/50">
            <Instagram size={16} className="text-primary flex-shrink-0" />
            <span className="font-body text-sm">@greattaster.paris</span>
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="font-display text-lg font-semibold text-foreground mb-4">Horaires</h4>
          <div className="flex items-start gap-3 text-foreground/50">
            <Clock size={16} className="text-primary mt-0.5 flex-shrink-0" />
            <div className="font-body text-sm space-y-1">
              <p>Mardi – Samedi : 19h00 – 23h00</p>
              <p>Dimanche : 12h00 – 15h00 (Brunch)</p>
              <p>Lundi : Fermé</p>
            </div>
          </div>
        </div>
      </div>

      <div className="section-divider mb-8" />
      <p className="text-center font-body text-xs text-foreground/30 tracking-widest uppercase">
        © 2025 Great Taster — Tous droits réservés
      </p>
    </div>
  </footer>
);

export default Footer;
