import heroBg from "@/assets/hero-bg.jpg";
import gallery1 from "@/assets/gallery-1.jpg";
import gallery2 from "@/assets/gallery-2.jpg";
import dish1 from "@/assets/dish-1.jpg";
import dish2 from "@/assets/dish-2.jpg";
import dish3 from "@/assets/dish-3.jpg";

const images = [
  { src: heroBg, alt: "Ambiance du restaurant", span: "md:col-span-2 md:row-span-2" },
  { src: gallery2, alt: "Dessert signature", span: "" },
  { src: dish1, alt: "Thiéboudienne signature", span: "" },
  { src: gallery1, alt: "Bar et salon", span: "md:col-span-2" },
  { src: dish2, alt: "Brochettes suya", span: "" },
  { src: dish3, alt: "Mafé grand cru", span: "" },
];

const GallerySection = () => (
  <section id="gallery" className="py-24 md:py-32 bg-background">
    <div className="container mx-auto px-6">
      <div className="text-center mb-16">
        <p className="font-elegant text-sm tracking-[0.3em] uppercase text-primary mb-4">Galerie</p>
        <h2 className="font-display text-3xl md:text-5xl font-bold text-foreground mb-4">
          L'Art de la <span className="text-gold-gradient">Table</span>
        </h2>
        <div className="section-divider" />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {images.map((img, i) => (
          <div
            key={i}
            className={`overflow-hidden group ${img.span}`}
          >
            <img
              src={img.src}
              alt={img.alt}
              className="w-full h-full min-h-[200px] object-cover group-hover:scale-105 transition-transform duration-700"
              loading="lazy"
            />
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default GallerySection;
