import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
const ReservationSection = () => {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    date: "",
    time: "",
    guests: "2",
    message: "",
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.date || !form.time) {
      toast.error("Veuillez remplir tous les champs obligatoires");
      return;
    }
    setLoading(true);
    try {
      const { error } = await supabase.from("reservations").insert({
        name: form.name,
        email: form.email,
        phone: form.phone || null,
        reservation_date: form.date,
        reservation_time: form.time,
        guests: form.guests,
        message: form.message || null,
      });
      if (error) throw error;
      toast.success("Réservation envoyée avec succès ! Nous vous confirmerons par email.");
      setForm({ name: "", email: "", phone: "", date: "", time: "", guests: "2", message: "" });
    } catch {
      toast.error("Erreur lors de l'envoi. Veuillez réessayer.");
    }
    setLoading(false);
    setLoading(false);
  };

  const inputClass =
    "w-full bg-secondary border border-border px-4 py-3 font-body text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 transition-colors";

  return (
    <section id="reservation" className="py-24 md:py-32 bg-secondary/50">
      <div className="container mx-auto px-6 max-w-3xl">
        <div className="text-center mb-16">
          <p className="font-elegant text-sm tracking-[0.3em] uppercase text-primary mb-4">Réservation</p>
          <h2 className="font-display text-3xl md:text-5xl font-bold text-foreground mb-4">
            Réservez votre <span className="text-gold-gradient">Table</span>
          </h2>
          <div className="section-divider mb-6" />
          <p className="font-body text-foreground/50">
            Pour une expérience inoubliable, réservez votre table dès maintenant
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid md:grid-cols-2 gap-5">
            <input
              name="name"
              type="text"
              placeholder="Nom complet *"
              value={form.name}
              onChange={handleChange}
              className={inputClass}
              required
            />
            <input
              name="email"
              type="email"
              placeholder="Email *"
              value={form.email}
              onChange={handleChange}
              className={inputClass}
              required
            />
          </div>
          <div className="grid md:grid-cols-3 gap-5">
            <input
              name="phone"
              type="tel"
              placeholder="Téléphone"
              value={form.phone}
              onChange={handleChange}
              className={inputClass}
            />
            <input
              name="date"
              type="date"
              value={form.date}
              onChange={handleChange}
              className={inputClass}
              required
            />
            <input
              name="time"
              type="time"
              value={form.time}
              onChange={handleChange}
              className={inputClass}
              required
            />
          </div>
          <div className="grid md:grid-cols-2 gap-5">
            <select
              name="guests"
              value={form.guests}
              onChange={handleChange}
              className={inputClass}
            >
              {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
                <option key={n} value={n}>
                  {n} {n === 1 ? "personne" : "personnes"}
                </option>
              ))}
              <option value="9+">9+ personnes (privatisation)</option>
            </select>
            <input
              name="message"
              type="text"
              placeholder="Demande spéciale (allergies, occasion...)"
              value={form.message}
              onChange={handleChange}
              className={inputClass}
            />
          </div>
          <div className="text-center pt-4">
            <button
              type="submit"
              disabled={loading}
              className="font-body text-xs tracking-[0.2em] uppercase px-14 py-4 bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-300 shadow-gold disabled:opacity-50"
            >
              {loading ? "Envoi en cours..." : "Confirmer la Réservation"}
            </button>
          </div>
        </form>
      </div>
    </section>
  );
};

export default ReservationSection;
