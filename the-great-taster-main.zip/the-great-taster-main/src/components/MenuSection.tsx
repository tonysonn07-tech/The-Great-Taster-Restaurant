import dish1 from "@/assets/dish-1.jpg";
import dish2 from "@/assets/dish-2.jpg";
import dish3 from "@/assets/dish-3.jpg";
import dish4 from "@/assets/dish-4.jpg";

interface MenuItem {
  name: string;
  description: string;
  price: string;
  image: string;
  origin: string;
}

const menuItems: MenuItem[] = [
  {
    name: "Thiéboudienne Signature",
    description: "Riz brisé au poisson noble, légumes de saison, sauce tomate fumée & bissap réduit",
    price: "32€",
    image: dish1,
    origin: "Sénégal",
  },
  {
    name: "Brochettes Suya Royales",
    description: "Filet de bœuf Black Angus, épices suya maison, poudre de cacahuète torréfiée & chimichurri africain",
    price: "28€",
    image: dish2,
    origin: "Nigeria",
  },
  {
    name: "Mafé Grand Cru",
    description: "Agneau confit 12h, sauce arachide aux épices douces, fonio soufflé & légumes racines",
    price: "35€",
    image: dish3,
    origin: "Mali",
  },
  {
    name: "Jollof Rice Prestige",
    description: "Riz parfumé au bouillon de homard, crevettes sauvages, plantain caramélisé & piment doux",
    price: "38€",
    image: dish4,
    origin: "Ghana",
  },
];

const MenuSection = () => (
  <section id="menu" className="py-24 md:py-32 bg-secondary/50">
    <div className="container mx-auto px-6">
      <div className="text-center mb-16">
        <p className="font-elegant text-sm tracking-[0.3em] uppercase text-primary mb-4">La Carte</p>
        <h2 className="font-display text-3xl md:text-5xl font-bold text-foreground mb-4">
          Nos Plats <span className="text-gold-gradient">Signature</span>
        </h2>
        <div className="section-divider mb-6" />
        <p className="font-body text-foreground/50 max-w-xl mx-auto">
          Chaque plat raconte une histoire, chaque saveur est un hommage à nos racines
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {menuItems.map((item) => (
          <div
            key={item.name}
            className="group bg-card border border-border hover:border-primary/30 transition-all duration-500 overflow-hidden flex"
          >
            <div className="w-40 h-48 flex-shrink-0 overflow-hidden">
              <img
                src={item.image}
                alt={item.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                loading="lazy"
              />
            </div>
            <div className="p-6 flex flex-col justify-between flex-1">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-display text-lg font-semibold text-foreground">{item.name}</h3>
                  <span className="font-display text-lg font-bold text-primary">{item.price}</span>
                </div>
                <span className="font-body text-[10px] tracking-[0.2em] uppercase text-primary/60 mb-3 inline-block">
                  {item.origin}
                </span>
                <p className="font-body text-sm text-foreground/50 leading-relaxed">{item.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default MenuSection;
