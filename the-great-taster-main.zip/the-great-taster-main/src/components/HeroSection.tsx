import heroBg from "@/assets/hero-bg.jpg";

const HeroSection = () => {
  const scrollTo = (href: string) => {
    const el = document.querySelector(href);
    el?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <img
        src={heroBg}
        alt="Great Taster restaurant interior"
        className="absolute inset-0 w-full h-full object-cover"
        loading="eager"
      />
      <div className="hero-overlay absolute inset-0" />

      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto animate-fade-up">
        <p className="font-elegant text-lg md:text-xl tracking-[0.3em] uppercase text-primary/80 mb-6">
          Cuisine pan-africaine d'exception
        </p>
        <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-bold mb-6 leading-tight">
          <span className="text-gold-gradient">Great Taster</span>
        </h1>
        <div className="section-divider mb-8" />
        <p className="font-elegant text-xl md:text-2xl text-foreground/70 max-w-2xl mx-auto mb-10 italic">
          Un voyage gastronomique au cœur de l'Afrique de l'Ouest, sublimé par l'élégance moderne
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={() => scrollTo("#menu")}
            className="font-body text-xs tracking-[0.2em] uppercase px-10 py-4 bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-300 shadow-gold"
          >
            Découvrir la Carte
          </button>
          <button
            onClick={() => scrollTo("#reservation")}
            className="font-body text-xs tracking-[0.2em] uppercase px-10 py-4 border border-primary/40 text-primary hover:bg-primary/10 transition-all duration-300"
          >
            Réserver une Table
          </button>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
