import galleryImg from "@/assets/gallery-1.jpg";

const AboutSection = () => (
  <section id="about" className="py-24 md:py-32 bg-background">
    <div className="container mx-auto px-6">
      <div className="grid md:grid-cols-2 gap-12 md:gap-20 items-center">
        <div className="relative">
          <div className="absolute -inset-4 border border-primary/10" />
          <img
            src={galleryImg}
            alt="Intérieur du restaurant Great Taster"
            className="w-full h-[500px] object-cover"
            loading="lazy"
          />
        </div>

        <div>
          <p className="font-elegant text-sm tracking-[0.3em] uppercase text-primary mb-4">Notre Histoire</p>
          <h2 className="font-display text-3xl md:text-5xl font-bold mb-6 text-foreground">
            L'Afrique dans <span className="text-gold-gradient">chaque bouchée</span>
          </h2>
          <div className="section-divider !mx-0 mb-8" />
          <p className="font-body text-foreground/60 leading-relaxed mb-6">
            Fondé avec la passion de sublimer les saveurs ancestrales de l'Afrique de l'Ouest,
            Great Taster est né d'un rêve audacieux : faire de la cuisine africaine une
            expérience gastronomique d'exception, digne des plus grandes tables du monde.
          </p>
          <p className="font-body text-foreground/60 leading-relaxed mb-8">
            Notre chef revisite les classiques — du thiéboudienne sénégalais au mafé malien,
            en passant par le jollof nigérian — avec une touche de raffinement contemporain,
            des produits d'une fraîcheur irréprochable et un dressage qui fait honneur à
            la richesse de notre patrimoine culinaire.
          </p>
          <div className="flex gap-12">
            {[
              { value: "2018", label: "Fondation" },
              { value: "15+", label: "Plats Signature" },
              { value: "★★", label: "Étoiles" },
            ].map((stat) => (
              <div key={stat.label}>
                <p className="font-display text-2xl font-bold text-primary">{stat.value}</p>
                <p className="font-body text-xs tracking-widest uppercase text-foreground/40 mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default AboutSection;
